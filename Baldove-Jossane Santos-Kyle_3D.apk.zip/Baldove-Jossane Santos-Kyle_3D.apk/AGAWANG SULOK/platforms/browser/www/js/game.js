var buttonPlay;
var platform, player, keyboard,ai,ais,ai1,ai1s,ai2,ai2s, stateText,
buttonIkap,hi,scoreInterval,over,gameScore, coin, manyCoin, manyCoins, ledge, pause,score;
var bounds = 15000;
var x = 5;
var goButton;
var menuText;
var playText;
var restart;
var score=0;
var upBtn;
var kananBtn;
var kaliwaBtn;
var abante = false;
var kanan = false;
var kaliwa = false;
var atras = false;
var nextAbante = 0;
var game = new Phaser.Game(800,600, Phaser.CANVAS, '');

game.state.add("bootGame", bootGame);
game.state.add("preloadGame", preloadGame);
game.state.add("menuGame", menuGame);
game.state.add("playGame", playGame);
game.state.add("winGame", playGame);
game.state.add("loseGame", loseGame);

game.state.start("bootGame");