bootGame = {
	
    create:function (){
        game.physics.startSystem(Phaser.Physics.ARCADE);
       // game.world.setBounds(0,0,bounds,0);
        keyboard = game.input.keyboard.createCursorKeys();

        game.scale.scaleMode = Phaser.ScaleManager.EXACT_FIT;
        game.scale.forcePortrait = true;
        game.scale.forceLandscape = false;
        game.scale.pageAlignHorizontally = true;
        game.scale.pageAlignVertically = true;
        game.scale.setScreenSize = true;
        game.state.start("preloadGame");

    },

    update:function(){
        game.scale.pageAlignHorizontally = true;
        game.scale.pageAlignVertically = true;
        game.scale.setShowAll();
        game.scale.refresh();


    }
}
preloadGame = {
    preload:function(){
        game.load.image('bg','img/bg.png');
        game.load.image('bgg','img/bgg.png');
        game.load.image('ground','img/platform.png');
        game.load.image('ground','img/platform2.png');
        game.load.image('ground','img/platform3.png');
        game.load.image('ground','img/platform4.png');
        game.load.spritesheet("start","img/startbut.png",263,117);
        game.load.spritesheet("menu2","img/menu2.png",95,94);
        game.load.image('about2','img/about2.png');
        game.load.image('play','img/play.png');
        game.load.image('ins','img/instruction.png');
        game.load.image('abawt','img/aboutbtn.png');
        game.load.image('intruc',"img/instruc.png");

        game.load.spritesheet("black","img/black.png",95,94);
        game.load.spritesheet('you','img/you.png',100,100);
        game.load.spritesheet('ai', 'img/dots1.png',100,100);
        game.load.spritesheet('ai2', 'img/dots2.png',100,100);
        game.load.spritesheet('ai3', 'img/dots3.png',100,100);
        game.load.spritesheet('ai4', 'img/dots4.png',100,100);
        game.load.spritesheet('buttonIkap','img/pause.png',70,70);

        game.load.spritesheet('UpButton','img/UpBtn.png',89,58);
        
        
        game.load.image('coin','img/gold.png');
        game.load.image('coin2','img/gold2.png');
        game.load.image('coin3','img/gold3.png');
        game.load.image('coin4','img/gold4.png');
        
    },
	create:function(){
		game.state.start("menuGame");
	}
}
menuGame = {
	create:function(){
        game.add.sprite(0,0, "bg");

        pbtn = game.add.button(400,390,"start",this.lundag);
        pbtn.anchor.set(0.5);
        pbtn.scale.set(0.8);  
         //pbtn.smoothed = false;

          tungkol = game.add.button(465,480,"abawt",this.tng);
                tungkol.anchor.set(0.8);

        la = game.add.button(400,510,"intruc",this.lala);
         la.anchor.set(0.5);
        la.scale.set(0.5);  
    },

lundag:function (){
        game.state.start("playGame");
   



   },

    tng: function(){
            about=game.add.image(0,0,"about2");
            about.scale.set(1);

            // restartButton=game.add.button(392,550,"gameover",restartB,this);
            // restartButton.scale.set(0.5);

            //  function restartB() {
            // about.visible =! restartButton.visible;
            // restartButton.destroy();
            restartButton=game.add.button(100,100,"menu2",restartB,this);
            function restartB() {
            //aboutpage.visible =! restartButton.visible;
            restartButton.destroy();

            // window.location.href=window.location.href;
            game.state.start("menuGame");
            }

            },
    lala: function(){
            about=game.add.image(0,0,"ins");
            about.scale.set(1);


            restartButton=game.add.button(100,50,"menu2",restartB,this);
            function restartB() {
            restartButton.destroy();

            game.state.start("menuGame");

            }

            },
   

}
playGame = {
	create:function(){
            console.log("current state: play");
    game.physics.startSystem(Phaser.Physics.ARCADE);
    game.scale.scaleMode = Phaser.ScaleManager.EXACT_FIT;
    game.scale.forcePortrait = true;
    game.scale.forceLandscape = false;
    game.scale.pageAlignHorizontally = true;
    game.scale.pageAlignVertically = true;;
    game.scale.setScreenSize = true;
    game.add.sprite(0,0,'bgg');

    over = game.add.text(100,100,'Game Over!',{font: '120px Comic Sans MS',fill:'maroon'});
    over.visible = false;

   

    player = game.add.sprite(360,270,'you'); 

    coin = game.add.sprite(720,270,'coin');
    coin2 = game.add.sprite(800,100,'coin2');
    coin3 = game.add.sprite(20,200,'coin3'); 
    coin4 = game.add.sprite(20,350,'coin4');

    cursors = game.input.keyboard.createCursorKeys();
    keyboard = game.input.keyboard.createCursorKeys();
    score = 0;
    
    

    game.physics.arcade.enable(player);

    game.physics.arcade.enable(coin);
    game.physics.arcade.enable(coin2);
    game.physics.arcade.enable(coin3);
    game.physics.arcade.enable(coin4);
    
    manyCoin = game.add.group();
    manyCoin.enableBody = true;

upbtn = game.add.button(680, 480, 'UpButton', null, this, 0, 1, 0, 1);  //game, x, y, key, callback, callbackContext, overFrame, outFrame, downFrame, upFrame
    upbtn.fixedToCamera = true;  //our buttons should stay on the same place
    upbtn.scale.set(0.7); 
    upbtn.anchor.set(0.5);
    upbtn.events.onInputOver.add(function(){abante=true;});
    upbtn.events.onInputOut.add(function(){abante=false;});
    upbtn.events.onInputDown.add(function(){abante=true;});
    upbtn.events.onInputUp.add(function(){abante=false;});

    downbtn = game.add.button(680, 580, 'UpButton', null, this, 0, 1, 0, 1);  //game, x, y, key, callback, callbackContext, overFrame, outFrame, downFrame, upFrame
    downbtn.fixedToCamera = true;  //our buttons should stay on the same place 
    downbtn.angle = 180; 
    downbtn.scale.set(0.7); 
    downbtn.anchor.set(0.5);
    downbtn.events.onInputOver.add(function(){atras=true;});
    downbtn.events.onInputOut.add(function(){atras=false;});
    downbtn.events.onInputDown.add(function(){atras=true;});
    downbtn.events.onInputUp.add(function(){atras=false;});

    kananbtn = game.add.button(740, 530, 'UpButton', null, this, 0, 1, 0, 1);  //game, x, y, key, callback, callbackContext, overFrame, outFrame, downFrame, upFrame
    kananbtn.angle = 90;
    kananbtn.anchor.setTo(0.5,0.5);
    kananbtn.scale.x = 0.8;
    kananbtn.scale.y = 0.8;
    kananbtn.fixedToCamera = true;  //our buttons should stay on the same place  
    kananbtn.events.onInputOver.add(function(){kanan=true;});
    kananbtn.events.onInputOut.add(function(){kanan=false;});
    kananbtn.events.onInputDown.add(function(){kanan=true;});
    kananbtn.events.onInputUp.add(function(){kanan=false;});

    kaliwabtn = game.add.button(620, 530, 'UpButton', null, this, 0, 1, 0, 1);  //game, x, y, key, callback, callbackContext, overFrame, outFrame, downFrame, upFrame
    kaliwabtn.angle = -90;
    kaliwabtn.anchor.setTo(0.5,0.5);
    kaliwabtn.scale.x = 0.8;
    kaliwabtn.scale.y = 0.8;
    kaliwabtn.fixedToCamera = true;  //our buttons should stay on the same place  
    kaliwabtn.events.onInputOver.add(function(){kaliwa=true;});
    kaliwabtn.events.onInputOut.add(function(){kaliwa=false;});
    kaliwabtn.events.onInputDown.add(function(){kaliwa=true;});
    kaliwabtn.events.onInputUp.add(function(){kaliwa=false;});
    //createCoins();

    score=game.add.text(100,10,"Score:0 ",{font:'17px Comic Sans MS', fill:'maroon'});
    
    hi=game.add.text(200,10,"High Score: " +sulok.getScore(),{font:'17px Comic Sans MS', fill:'maroon'});
    // hi = game.add.text(200,16,'Score: ',{fill:"maroon"});
    // scoreText = game.add.text(60,16,'Best: '+sulok.getScore(),{fill:"maroon"});
    
    ai = game.add.sprite(130,80,'ai');
    

    ai2 = game.add.sprite(200,80,'ai2');
    

    ai3 = game.add.sprite(600,80,'ai3');
    

    ai4 = game.add.sprite(535,80,'ai4');
   

    platforms = game.add.group(); 
    ledge = platforms.create(0, 340, 'ground');
    game.physics.arcade.enable(ledge);
    ledge.body.immovable=true;
    ledge.scale.x = 0.5;

    platform2 = game.add.group(); 
    ledge2 = platform2.create(600, 340, 'ground');
    game.physics.arcade.enable(ledge2);
    ledge2.body.immovable=true;
    ledge2.scale.x = 0.5;

     platform3 = game.add.group(); 
    ledge3 = platform3.create(255, 100, 'ground');
    game.physics.arcade.enable(ledge3);
    ledge3.body.immovable=true;
    ledge3.scale.x = 0.7;   

     platform4 = game.add.group(); 
    ledge4 = platform4.create(255, 500, 'ground');
    game.physics.arcade.enable(ledge4);
    ledge4.body.immovable=true;
    ledge4.scale.x = 0.7;

   

    
 
    game.physics.arcade.enable(player);
    player.body.collideWorldBounds = true;
    player.body.gravity.y = 0;
    game.physics.arcade.enable(ai);
    ai.body.collideWorldBounds = true;
    ai.body.velocity.y=-300;
    ai.body.bounce.y=1;

    game.physics.arcade.enable(ai2);
    ai2.body.collideWorldBounds = true;
    ai2.body.velocity.y=-400;
    ai2.body.bounce.y=1;

    game.physics.arcade.enable(ai3);
    ai3.body.collideWorldBounds = true;
    ai3.body.velocity.y=-370;
    ai3.body.bounce.y=1;

    game.physics.arcade.enable(ai4);
    ai4.body.collideWorldBounds = true;
    ai4.body.velocity.y=-470;
    ai4.body.bounce.y=1;

    game.physics.arcade.enable(coin);
    coin.body.collideWorldBounds = true;
    coin.body.gravity.y = 400;
    coin.body.bounce.y = 1;
    
  

   game.physics.arcade.enable(coin2);
    coin2.body.collideWorldBounds = true;
    coin2.body.gravity.y = 400;
    coin2.body.bounce.y = 1;
   

   game.physics.arcade.enable(coin3);
    coin3.body.collideWorldBounds = true;
    coin3.body.gravity.y = 400;
    coin3.body.bounce.y = 1;
   

   game.physics.arcade.enable(coin4);
    coin4.body.collideWorldBounds = true;
    coin4.body.gravity.y = 400;
    coin4.body.bounce.y = 1;
   

    buttonIkap = game.add.button(10,16,"buttonIkap",sulok.PlayPause);

    stateText = game.add.text(game.world.centerX,game.world.centerY,' ', { font: '50px Comic Sans MS', fill: 'maroon' });
    stateText.anchor.setTo(0.4, 0.10);
    stateText.visible = false;

    // buttonRight = game.add.button(700,400,"btn-right",sulok.rightyou);
    // buttonLeft = game.add.button(600,400,"btn-left",sulok.leftyou);
    // buttonUp = game.add.button(650,350,"btn-up",sulok.upyou);
    // buttonDown = game.add.button(650,450,"btn-down",sulok.downyou);


    },
    update:function (){
game.physics.arcade.collide(player,coin);
game.physics.arcade.collide(player,coin2);
game.physics.arcade.collide(player,coin3);
game.physics.arcade.collide(player,coin4);

    // player.body.velocity.x = 0;
    // player.body.velocity.y = 0;
if (abante && !nextAbante) {
       
        player.body.velocity.y = -400;

    }
     else if (atras && !nextAbante) {
       
      
        player.body.velocity.y = 400;

    }
    else if (kanan && !nextAbante) {
       
        player.body.velocity.x = 400;

    }
    else if (kaliwa && !nextAbante) {
       
        
        player.body.velocity.x = -400;
        }




    score.text = "Score : " +x;

    if(sulok.getScore()<=x){
            sulok.saveScore(x);
            hi.text="HIGH SCORE: "+x;
        }

if (game.physics.arcade.collide(player,coin)){

        
        
        coin.kill();
        x+=5;
        score.text="Score: "+x;
        

    }

    if (game.physics.arcade.collide(player,coin2)){

        
        
        coin2.kill();
        x+=5;
        score.text="Score: "+x;
        
    }

    if (game.physics.arcade.collide(player,coin3)){

        
        
        coin3.kill();
        x+=5;
        score.text="Score: "+x;

    }

    if (game.physics.arcade.collide(player,coin4)){

        
        
        coin4.kill();
        
         x+=5;
        score.text="Score: "+x;
    }

    if (game.physics.arcade.collide(ai,player)){

        
        
        player.kill();
        game._paused=true
        over.visible =true;
        
        sulok.restart.visible = true;
        // hi.visible=true;
        // score.visible=true


                stateText.text="Tap to restart";
                stateText.visible = true;

                
                game.input.onTap.addOnce(sulok.restart,this);

    }
    if (game.physics.arcade.collide(ai2,player)){

        
        
        player.kill();
        game._paused=true
        over.visible =true;
        
        sulok.restart.visible = true;
        // hi.visible=true;
        // score.visible=true


                stateText.text="Tap to restart";
                stateText.visible = true;

                
                game.input.onTap.addOnce(sulok.restart,this);

    }
    if (game.physics.arcade.collide(ai3,player)){

        
        
        player.kill();
        game._paused=true
        over.visible =true;
        
        sulok.restart.visible = true;
        // hi.visible=true;
        // score.visible=true


                stateText.text="Tap to restart";
                stateText.visible = true;

                
                game.input.onTap.addOnce(sulok.restart,this);

    }

    if (game.physics.arcade.collide(ai4,player)){

        
        
        player.kill();
        game._paused=true
        over.visible =true;
        
        sulok.restart.visible = true;
        // hi.visible=true;
        // score.visible=true


                stateText.text="Tap to restart";
                stateText.visible = true;

                
                game.input.onTap.addOnce(sulok.restart,this);

    }

        game.physics.arcade.collide(ledge,player);
        game.physics.arcade.collide(ledge2,player);
        game.physics.arcade.collide(ledge3,player);
        game.physics.arcade.collide(ledge4,player);

        game.physics.arcade.collide(ledge,ai);
        game.physics.arcade.collide(ledge2,ai);
        game.physics.arcade.collide(ledge3,ai);
        game.physics.arcade.collide(ledge4,ai);

        game.physics.arcade.collide(ledge,ai2);
        game.physics.arcade.collide(ledge2,ai2);
        game.physics.arcade.collide(ledge3,ai2);
        game.physics.arcade.collide(ledge4,ai2);


        game.physics.arcade.collide(ledge,ai3);
        game.physics.arcade.collide(ledge2,ai3);
        game.physics.arcade.collide(ledge3,ai3);
        game.physics.arcade.collide(ledge4,ai3);

        game.physics.arcade.collide(ledge,ai4);
        game.physics.arcade.collide(ledge2,ai4);
        game.physics.arcade.collide(ledge3,ai4);
        game.physics.arcade.collide(ledge4,ai4);


        game.physics.arcade.collide(ledge,coin);
        game.physics.arcade.collide(ledge2,coin);
        game.physics.arcade.collide(ledge3,coin);
        game.physics.arcade.collide(ledge4,coin);

        game.physics.arcade.collide(ledge,coin2);
        game.physics.arcade.collide(ledge2,coin2);
        game.physics.arcade.collide(ledge3,coin2);
        game.physics.arcade.collide(ledge4,coin2);

        game.physics.arcade.collide(ledge,coin3);
        game.physics.arcade.collide(ledge2,coin3);
        game.physics.arcade.collide(ledge3,coin3);
        game.physics.arcade.collide(ledge4,coin3);

        game.physics.arcade.collide(ledge,coin4);
        game.physics.arcade.collide(ledge2,coin4);
        game.physics.arcade.collide(ledge3,coin4);
        game.physics.arcade.collide(ledge4,coin4);



        


    if(keyboard.right.isDown){
        player.body.velocity.x=270
    }
    else{
        ai.animations.play('ai')
    }
    if(keyboard.right.isDown){
        player.body.velocity.x=270
    }
    else{
        ai.animations.play('ai2')
    }
    if(keyboard.right.isDown){
        player.body.velocity.x=270
    }
    else{
        ai.animations.play('ai3')
    }
    if(keyboard.right.isDown){
        player.body.velocity.x=270
    }
    else{
        ai.animations.play('ai4')
    }
    if(keyboard.left.isDown){
        player.body.velocity.x = -400;
        player.animations.play('walk-left');
    }
    else if(keyboard.right.isDown){
        player.body.velocity.x = 400;
        player.animations.play('walk-right');
    }
    else if(keyboard.up.isDown){
        player.body.velocity.y = -400;
    }
    else if(keyboard.down.isDown){
        player.body.velocity.y = 400;
    }

    
    if(keyboard.up.isDown && player.body.touching.down){
        player.body.velocity.y = -500; 
     }


     
}
};
var sulok = function(){
    "use strict";
    return {  
        play:function(){
            buttonPlay.destroy();
        },

leftyou: function() {
        buttonLeft.frame = 1;
        player.animations.play('walk-left');
        player.body.velocity.x = -300;
        
    
    setTimeout(function(){
        buttonLeft.frame = 0;
        player.body.velocity.x = 0;
        player.animations.stop();
    },100)
},
        rightyou: function(){
        buttonRight.frame = 1;
        player.body.velocity.x = 300;
        player.animations.play('walk-right');
        
    setTimeout(function(){
        buttonyou.frame = 0;
        player.body.velocity.x = 0;
        player.animations.stop();
    },100)
},
        upyou: function() {
        buttonUp.frame = 1;
        player.body.velocity.y =-500;
        player.animations.play('walk-up');
        
        setTimeout(function(){
        buttonUp.frame = 0;
        player.body.velocity.x = 0;
        player.animations.stop();
        },100)
},
        downyou: function() {
        buttonDown.frame = 1;
        player.body.velocity.y = 500;
        player.animations.play('walk-down');
        
        setTimeout(function(){
        buttonDown.frame = 0;
        player.body.velocity.x = 0;
        player.animations.stop();
  
        },100)

            }
        }
};


var sulok = function(){
    "use strict";
    return {  
        play:function(){
            buttonPlay.destroy();
        },

collectCoins: function(player,coin){
    x = x + 5;
    coin.kill();
    if(getScore()<=x){
        saveScore(x);
        hi.text = "High Score: "+x;
    }

    score.text = "Score: "+x;
},
collectCoins: function(player,coin2){
    x = x + 5;
    coin2.kill();
    if(getScore()<=x){
        saveScore(x);
        hi.text = "High Score: "+x;
    }

    score.text = "Score: "+x;
},
collectCoins: function(player,coin3){
    x = x + 5;
    coin3.kill();
    if(getScore()<=x){
        saveScore(x);
        hi.text = "High Score: "+x;
    }

    score.text = "Score: "+x;
},
collectCoins: function(player,coin4){
    x = x + 5;
    coin4.kill();
    if(getScore()<=x){
        saveScore(x);
        hi.text = "High Score: "+x;
    }

    score.text = "Score: "+x;
},

PlayPause: function(){
                buttonIkap.frame = 1;
                game._paused = true;

                setTimeout(function(){
                buttonIkap.frame = 0;
                },100);


                setTimeout(function(){
                game._paused = false;
                },4000);
                },
restart: function() {
    window.location.href=window.location.href;
    stateText.visible = false;
},
saveScore: function(score){
    localStorage.setItem("gameScore",score);
},

getScore: function(){
    return (localStorage.getItem("gameScore") == null || localStorage.getItem("gameScore") == "")?0:localStorage.getItem("gameScore");
},

           }
            }();


winGame = {
    preload:function(){

    },
    create:function(){

    },
    update:function(){

    }
    
}

loseGame = {
    preload:function(){

    },
    create:function(){

    },
    update:function(){

    }
    
}
